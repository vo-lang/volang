module = "github.com/vo-lang/test/subdir"
vo = "^0.1.0"
