format = 1
module = "github.com/vo-lang/test/subdir"
version = "0.1.0"
vo = "0.1.0"
