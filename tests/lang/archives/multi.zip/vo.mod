module = "github.com/vo-lang/test/multi"
vo = "^0.1.0"
